//! # Description
//! This module contains various validators for the `additionalProperties` keyword.
//!
//! The goal here is to compute intersections with another keywords affecting properties validation:
//!   - `properties`
//!   - `patternProperties`
//!
//! Each valid combination of these keywords has a validator here.
use crate::reference::{Uri, Vocabulary};
use crate::validation::{
    compiler,
    error::ValidationError,
    evaluation::{Annotations, ChildList, ErrorDescription, EvaluationNode},
    keywords::CompilationResult,
    node::SchemaNode,
    options::PatternEngineOptions,
    paths::{LazyLocation, Location, RefTracker},
    properties::{
        are_properties_valid, compile_big_map, compile_dynamic_prop_map_validator,
        compile_fancy_regex_patterns, compile_regex_patterns, compile_small_map, BigValidatorsMap,
        CompiledPattern, PropertiesValidatorsMap, SmallValidatorsMap, HASHMAP_THRESHOLD,
    },
    regex::RegexEngine,
    types::JsonType,
    validator::{EvaluationResult, Validate, ValidationContext},
    Json, JsonValueBackend, LazyInstance, Node, Object,
};
use ahash::AHashMap;
use json_codec::{Map, Value};
use std::{borrow::Cow, sync::Arc};

/// # Schema example
///
/// ```json
/// {
///     "additionalProperties": {"type": "integer"},
/// }
/// ```
///
/// # Valid value
///
/// ```json
/// {
///     "bar": 6
/// }
/// ```
pub(crate) struct AdditionalPropertiesValidator<F: Json = JsonValueBackend> {
    node: SchemaNode<F>,
}
impl AdditionalPropertiesValidator {
    #[inline]
    pub(crate) fn compile<'a, F: Json>(
        schema: &'a Value,
        ctx: &compiler::Context<F>,
    ) -> CompilationResult<'a, F> {
        let ctx = ctx.new_at_location("additionalProperties");
        Ok(Box::new(AdditionalPropertiesValidator {
            node: compiler::compile(&ctx, ctx.as_resource_ref(schema))?,
        }))
    }
}
impl<F: Json> Validate<F> for AdditionalPropertiesValidator<F> {
    fn is_valid(&self, instance: &F::Node<'_>, ctx: &mut ValidationContext) -> bool {
        if let Some(object) = instance.as_object() {
            object
                .members()
                .all(|(_, value)| self.node.is_valid(&value, ctx))
        } else {
            true
        }
    }

    fn validate<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> Result<(), ValidationError<'i>> {
        if let Some(object) = instance.as_object() {
            for (name, value) in object.members() {
                self.node
                    .validate(&value, &location.push(name.as_ref()), tracker, ctx)?;
            }
        }
        Ok(())
    }

    fn collect_errors<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
        errors: &mut Vec<ValidationError<'i>>,
    ) {
        let Some(object) = instance.as_object() else {
            return;
        };
        for (name, value) in object.members() {
            self.node
                .collect_errors(&value, &location.push(name.as_ref()), tracker, ctx, errors);
        }
    }

    fn evaluate(
        &self,
        instance: &F::Node<'_>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> EvaluationResult {
        if let Some(object) = instance.as_object() {
            let mut children = ChildList::default();
            for (name, value) in object.members() {
                let child = self.node.evaluate_instance_below(
                    &value,
                    &location.push(name.as_ref()),
                    tracker,
                    ctx,
                );
                children.push(&mut ctx.arena, child);
            }
            let mut result = EvaluationResult::from_children(children);
            let annotated_props = object
                .members()
                .map(|(name, _)| json_codec::Value::String(name.as_ref().to_owned()))
                .collect();
            result.annotate(Annotations::new(json_codec::Value::Array(annotated_props)));
            result
        } else {
            EvaluationResult::valid_empty()
        }
    }
}

/// # Schema example
///
/// ```json
/// {
///     "additionalProperties": false
/// }
/// ```
///
/// # Valid value
///
/// ```json
/// {}
/// ```
pub(crate) struct AdditionalPropertiesFalseValidator {
    location: Location,
}
impl AdditionalPropertiesFalseValidator {
    #[inline]
    pub(crate) fn compile<'a, F: Json>(location: Location) -> CompilationResult<'a, F> {
        Ok(Box::new(AdditionalPropertiesFalseValidator { location }))
    }
}
impl<F: Json> Validate<F> for AdditionalPropertiesFalseValidator {
    fn is_valid(&self, instance: &F::Node<'_>, _ctx: &mut ValidationContext) -> bool {
        if let Some(object) = instance.as_object() {
            object.members().next().is_none()
        } else {
            true
        }
    }

    fn validate<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        _ctx: &mut ValidationContext,
    ) -> Result<(), ValidationError<'i>> {
        if let Some(object) = instance.as_object() {
            if let Some((_, value)) = object.members().next() {
                return Err(ValidationError::false_schema(
                    self.location.clone(),
                    crate::validation::paths::capture_evaluation_path(tracker, &self.location),
                    location.into(),
                    value.lazy_value(),
                ));
            }
        }
        Ok(())
    }
}

/// # Schema example
///
/// ```json
/// {
///     "additionalProperties": false,
///     "properties": {
///         "foo": {"type": "string"}
///     },
/// }
/// ```
///
/// # Valid value
///
/// ```json
/// {
///     "foo": "bar",
/// }
/// ```
pub(crate) struct AdditionalPropertiesNotEmptyFalseValidator<M> {
    properties: M,
    location: Location,
}
impl<F: Json> AdditionalPropertiesNotEmptyFalseValidator<SmallValidatorsMap<F>> {
    #[inline]
    pub(crate) fn compile<'a>(
        map: &'a Map<String, Value>,
        ctx: &compiler::Context<F>,
    ) -> CompilationResult<'a, F> {
        Ok(Box::new(AdditionalPropertiesNotEmptyFalseValidator {
            properties: compile_small_map(ctx, map)?,
            location: ctx.location().join("additionalProperties"),
        }))
    }
}
impl<F: Json> AdditionalPropertiesNotEmptyFalseValidator<BigValidatorsMap<F>> {
    #[inline]
    pub(crate) fn compile<'a>(
        map: &'a Map<String, Value>,
        ctx: &compiler::Context<F>,
    ) -> CompilationResult<'a, F> {
        Ok(Box::new(AdditionalPropertiesNotEmptyFalseValidator {
            properties: compile_big_map(ctx, map)?,
            location: ctx.location().join("additionalProperties"),
        }))
    }
}
impl<F: Json, M: PropertiesValidatorsMap<F>> Validate<F>
    for AdditionalPropertiesNotEmptyFalseValidator<M>
{
    fn is_valid(&self, instance: &F::Node<'_>, ctx: &mut ValidationContext) -> bool {
        if let Some(object) = instance.as_object() {
            are_properties_valid(&self.properties, &object, ctx, |_, _| false)
        } else {
            true
        }
    }

    fn validate<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> Result<(), ValidationError<'i>> {
        if let Some(object) = instance.as_object() {
            for (property, value) in object.members() {
                if let Some((name, node)) = self.properties.get_key_validator(property.as_ref()) {
                    node.validate(&value, &location.push(name), tracker, ctx)?;
                } else {
                    return Err(ValidationError::additional_properties(
                        self.location.clone(),
                        crate::validation::paths::capture_evaluation_path(tracker, &self.location),
                        location.into(),
                        instance.lazy_value(),
                        vec![property.as_ref().to_owned()],
                    ));
                }
            }
        }
        Ok(())
    }

    fn collect_errors<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
        errors: &mut Vec<ValidationError<'i>>,
    ) {
        let Some(object) = instance.as_object() else {
            return;
        };
        let mut unexpected = vec![];
        for (property, value) in object.members() {
            if let Some((name, node)) = self.properties.get_key_validator(property.as_ref()) {
                node.collect_errors(&value, &location.push(name), tracker, ctx, errors);
            } else {
                unexpected.push(property.as_ref().to_owned());
            }
        }
        if !unexpected.is_empty() {
            errors.push(ValidationError::additional_properties(
                self.location.clone(),
                crate::validation::paths::capture_evaluation_path(tracker, &self.location),
                location.into(),
                instance.lazy_value(),
                unexpected,
            ));
        }
    }

    fn evaluate(
        &self,
        instance: &F::Node<'_>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> EvaluationResult {
        if let Some(object) = instance.as_object() {
            let mut unexpected = Vec::with_capacity(object.len());
            let mut children = ChildList::default();
            for (property, value) in object.members() {
                if let Some((_name, node)) = self.properties.get_key_validator(property.as_ref()) {
                    let child = node.evaluate_instance_below(
                        &value,
                        &location.push(property.as_ref()),
                        tracker,
                        ctx,
                    );
                    children.push(&mut ctx.arena, child);
                } else {
                    unexpected.push(property.as_ref().to_owned());
                }
            }
            let mut result = EvaluationResult::from_children(children);
            if !unexpected.is_empty() {
                let eval_path =
                    crate::validation::paths::capture_evaluation_path(tracker, &self.location);
                result.mark_errored(ErrorDescription::from_validation_error(
                    &ValidationError::additional_properties(
                        self.location.clone(),
                        eval_path,
                        location.into(),
                        instance.lazy_value(),
                        unexpected,
                    ),
                ));
            }
            result
        } else {
            EvaluationResult::valid_empty()
        }
    }
}

// Container members `is_valid` holds back; past this many they are validated as they come.
const DEFERRED_MEMBERS: usize = 4;

/// Fused validator for properties + additionalProperties: false + required
/// Eliminates separate required validation pass by tracking the required property during iteration.
pub(crate) struct AdditionalPropertiesNotEmptyFalseWithRequired1Validator<M> {
    properties: M,
    required: String,
    location: Location,
    required_location: Location,
    required_absolute_location: Option<Arc<Uri<String>>>,
}
impl<M> AdditionalPropertiesNotEmptyFalseWithRequired1Validator<M> {
    fn new<F: Json>(properties: M, ctx: &compiler::Context<F>, required: String) -> Self {
        let required_location = ctx.location().join("required");
        AdditionalPropertiesNotEmptyFalseWithRequired1Validator {
            properties,
            required,
            location: ctx.location().join("additionalProperties"),
            required_absolute_location: ctx.absolute_location(&required_location),
            required_location,
        }
    }

    #[cold]
    #[inline(never)]
    fn missing_required<'i, F: Json>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
    ) -> ValidationError<'i> {
        ValidationError::required(
            self.required_location.clone(),
            crate::validation::paths::capture_evaluation_path(tracker, &self.required_location),
            location.into(),
            instance.lazy_value(),
            Value::String(self.required.clone()),
        )
        .with_absolute_keyword_location(self.required_absolute_location.clone())
    }
}
impl<F: Json> AdditionalPropertiesNotEmptyFalseWithRequired1Validator<SmallValidatorsMap<F>> {
    #[inline]
    pub(crate) fn compile<'a>(
        map: &'a Map<String, Value>,
        ctx: &compiler::Context<F>,
        required: String,
    ) -> CompilationResult<'a, F> {
        Ok(Box::new(
            AdditionalPropertiesNotEmptyFalseWithRequired1Validator::new(
                compile_small_map(ctx, map)?,
                ctx,
                required,
            ),
        ))
    }
}
impl<F: Json> AdditionalPropertiesNotEmptyFalseWithRequired1Validator<BigValidatorsMap<F>> {
    #[inline]
    pub(crate) fn compile<'a>(
        map: &'a Map<String, Value>,
        ctx: &compiler::Context<F>,
        required: String,
    ) -> CompilationResult<'a, F> {
        Ok(Box::new(
            AdditionalPropertiesNotEmptyFalseWithRequired1Validator::new(
                compile_big_map(ctx, map)?,
                ctx,
                required,
            ),
        ))
    }
}
impl<F: Json, M: PropertiesValidatorsMap<F>> Validate<F>
    for AdditionalPropertiesNotEmptyFalseWithRequired1Validator<M>
{
    fn is_valid(&self, instance: &F::Node<'_>, ctx: &mut ValidationContext) -> bool {
        if let Some(object) = instance.as_object() {
            // Scalars are checked as they come; containers wait until every member is known to be
            // declared. An undeclared member then rejects before any deep validation, and a cheap
            // discriminator (a `const` scalar) rejects early, whatever order members arrive in.
            let mut deferred: [Option<(&SchemaNode<F>, F::Node<'_>)>; DEFERRED_MEMBERS] =
                [const { None }; DEFERRED_MEMBERS];
            let mut count = 0;
            let mut found_required = false;
            for (property, value) in object.members() {
                let Some(node) = self.properties.get_validator(property.as_ref()) else {
                    return false;
                };
                found_required |= property.as_ref() == self.required.as_str();
                if count < DEFERRED_MEMBERS
                    && matches!(value.json_type(), JsonType::Array | JsonType::Object)
                {
                    deferred[count] = Some((node, value));
                    count += 1;
                } else if !node.is_valid(&value, ctx) {
                    return false;
                }
            }
            found_required
                && deferred[..count]
                    .iter()
                    .flatten()
                    .all(|(node, value)| node.is_valid(value, ctx))
        } else {
            true
        }
    }

    fn validate<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> Result<(), ValidationError<'i>> {
        if let Some(object) = instance.as_object() {
            let mut found_required = false;
            for (property, value) in object.members() {
                if let Some((name, node)) = self.properties.get_key_validator(property.as_ref()) {
                    node.validate(&value, &location.push(name), tracker, ctx)?;
                    if property.as_ref() == self.required.as_str() {
                        found_required = true;
                    }
                } else {
                    return Err(ValidationError::additional_properties(
                        self.location.clone(),
                        crate::validation::paths::capture_evaluation_path(tracker, &self.location),
                        location.into(),
                        instance.lazy_value(),
                        vec![property.as_ref().to_owned()],
                    ));
                }
            }
            if !found_required {
                return Err(self.missing_required::<F>(instance, location, tracker));
            }
        }
        Ok(())
    }

    fn collect_errors<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
        errors: &mut Vec<ValidationError<'i>>,
    ) {
        let Some(object) = instance.as_object() else {
            return;
        };
        let mut unexpected = vec![];
        let mut found_required = false;
        for (property, value) in object.members() {
            if let Some((name, node)) = self.properties.get_key_validator(property.as_ref()) {
                node.collect_errors(&value, &location.push(name), tracker, ctx, errors);
                if property.as_ref() == self.required.as_str() {
                    found_required = true;
                }
            } else {
                unexpected.push(property.as_ref().to_owned());
            }
        }
        if !unexpected.is_empty() {
            errors.push(ValidationError::additional_properties(
                self.location.clone(),
                crate::validation::paths::capture_evaluation_path(tracker, &self.location),
                location.into(),
                instance.lazy_value(),
                unexpected,
            ));
        }
        if !found_required {
            errors.push(self.missing_required::<F>(instance, location, tracker));
        }
    }

    fn evaluate(
        &self,
        instance: &F::Node<'_>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> EvaluationResult {
        if let Some(object) = instance.as_object() {
            let mut unexpected = Vec::with_capacity(object.len());
            let mut children = ChildList::default();
            let mut found_required = false;
            for (property, value) in object.members() {
                if let Some((_name, node)) = self.properties.get_key_validator(property.as_ref()) {
                    let child = node.evaluate_instance_below(
                        &value,
                        &location.push(property.as_ref()),
                        tracker,
                        ctx,
                    );
                    children.push(&mut ctx.arena, child);
                    if property.as_ref() == self.required.as_str() {
                        found_required = true;
                    }
                } else {
                    unexpected.push(property.as_ref().to_owned());
                }
            }
            let mut result = EvaluationResult::from_children(children);
            if !unexpected.is_empty() {
                let eval_path =
                    crate::validation::paths::capture_evaluation_path(tracker, &self.location);
                result.mark_errored(ErrorDescription::from_validation_error(
                    &ValidationError::additional_properties(
                        self.location.clone(),
                        eval_path,
                        location.into(),
                        instance.lazy_value(),
                        unexpected,
                    ),
                ));
            }
            if !found_required {
                let eval_path = crate::validation::paths::capture_evaluation_path(
                    tracker,
                    &self.required_location,
                );
                result.mark_errored(ErrorDescription::from_validation_error(
                    &ValidationError::required(
                        self.required_location.clone(),
                        eval_path,
                        location.into(),
                        instance.lazy_value(),
                        Value::String(self.required.clone()),
                    ),
                ));
            }
            result
        } else {
            EvaluationResult::valid_empty()
        }
    }
}

/// # Schema example
///
/// ```json
/// {
///     "additionalProperties": {"type": "integer"},
///     "properties": {
///         "foo": {"type": "string"}
///     }
/// }
/// ```
///
/// # Valid value
///
/// ```json
/// {
///     "foo": "bar",
///     "bar": 6
/// }
/// ```
pub(crate) struct AdditionalPropertiesNotEmptyValidator<M, F: Json = JsonValueBackend> {
    node: SchemaNode<F>,
    properties: M,
}
impl<F: Json> AdditionalPropertiesNotEmptyValidator<SmallValidatorsMap<F>> {
    #[inline]
    pub(crate) fn compile<'a>(
        map: &'a Map<String, Value>,
        ctx: &compiler::Context<F>,
        schema: &'a Value,
    ) -> CompilationResult<'a, F> {
        let kctx = ctx.new_at_location("additionalProperties");
        Ok(Box::new(AdditionalPropertiesNotEmptyValidator {
            properties: compile_small_map(ctx, map)?,
            node: compiler::compile(&kctx, kctx.as_resource_ref(schema))?,
        }))
    }
}
impl<F: Json> AdditionalPropertiesNotEmptyValidator<BigValidatorsMap<F>> {
    #[inline]
    pub(crate) fn compile<'a>(
        map: &'a Map<String, Value>,
        ctx: &compiler::Context<F>,
        schema: &'a Value,
    ) -> CompilationResult<'a, F> {
        let kctx = ctx.new_at_location("additionalProperties");
        Ok(Box::new(AdditionalPropertiesNotEmptyValidator {
            properties: compile_big_map(ctx, map)?,
            node: compiler::compile(&kctx, kctx.as_resource_ref(schema))?,
        }))
    }
}
impl<F: Json, M: PropertiesValidatorsMap<F>> Validate<F>
    for AdditionalPropertiesNotEmptyValidator<M, F>
{
    fn is_valid(&self, instance: &F::Node<'_>, ctx: &mut ValidationContext) -> bool {
        if let Some(object) = instance.as_object() {
            are_properties_valid(&self.properties, &object, ctx, |instance, ctx| {
                self.node.is_valid(instance, ctx)
            })
        } else {
            true
        }
    }

    fn validate<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> Result<(), ValidationError<'i>> {
        if let Some(object) = instance.as_object() {
            for (property, value) in object.members() {
                let property_location = location.push(property.as_ref());
                if let Some(validator) = self.properties.get_validator(property.as_ref()) {
                    validator.validate(&value, &property_location, tracker, ctx)?;
                } else {
                    self.node
                        .validate(&value, &property_location, tracker, ctx)?;
                }
            }
        }
        Ok(())
    }

    fn collect_errors<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
        errors: &mut Vec<ValidationError<'i>>,
    ) {
        let Some(object) = instance.as_object() else {
            return;
        };
        for (property, value) in object.members() {
            if let Some((name, property_validators)) =
                self.properties.get_key_validator(property.as_ref())
            {
                property_validators.collect_errors(
                    &value,
                    &location.push(name),
                    tracker,
                    ctx,
                    errors,
                );
            } else {
                self.node.collect_errors(
                    &value,
                    &location.push(property.as_ref()),
                    tracker,
                    ctx,
                    errors,
                );
            }
        }
    }

    fn evaluate(
        &self,
        instance: &F::Node<'_>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> EvaluationResult {
        if let Some(object) = instance.as_object() {
            let mut matched_propnames = Vec::with_capacity(object.len());
            let mut children = ChildList::default();
            for (property, value) in object.members() {
                let path = location.push(property.as_ref());
                if let Some((_name, property_validators)) =
                    self.properties.get_key_validator(property.as_ref())
                {
                    let child =
                        property_validators.evaluate_instance_below(&value, &path, tracker, ctx);
                    children.push(&mut ctx.arena, child);
                } else {
                    let child = self
                        .node
                        .evaluate_instance_below(&value, &path, tracker, ctx);
                    children.push(&mut ctx.arena, child);
                    matched_propnames.push(property.as_ref().to_owned());
                }
            }
            let mut result = EvaluationResult::from_children(children);
            if !matched_propnames.is_empty() {
                result.annotate(Annotations::new(Value::from(matched_propnames)));
            }
            result
        } else {
            EvaluationResult::valid_empty()
        }
    }
}

/// # Schema example
///
/// ```json
/// {
///     "additionalProperties": {"type": "integer"},
///     "patternProperties": {
///         "^x-": {"type": "integer", "minimum": 5},
///         "-x$": {"type": "integer", "maximum": 10}
///     }
/// }
/// ```
///
/// # Valid value
///
/// ```json
/// {
///     "x-foo": 6,
///     "foo-x": 7,
///     "bar": 8
/// }
/// ```
pub(crate) struct AdditionalPropertiesWithPatternsValidator<R, F: Json = JsonValueBackend> {
    node: SchemaNode<F>,
    patterns: Vec<(R, SchemaNode<F>)>,
    /// We need this because `compiler::compile` uses the additionalProperties keyword to compile
    /// this validator. That means that the schema node which contains this validator has
    /// "additionalProperties" as it's path. However, we need to produce annotations which have the
    /// patternProperties keyword as their path so we store the paths here.
    pattern_keyword_path: Location,
    pattern_keyword_absolute_location: Option<Arc<Uri<String>>>,
}

impl<F: Json, R: RegexEngine> Validate<F> for AdditionalPropertiesWithPatternsValidator<R, F> {
    fn is_valid(&self, instance: &F::Node<'_>, ctx: &mut ValidationContext) -> bool {
        if let Some(object) = instance.as_object() {
            for (property, value) in object.members() {
                let mut has_match = false;
                for (re, node) in &self.patterns {
                    if re.is_match(property.as_ref()).unwrap_or(false) {
                        has_match = true;
                        if !node.is_valid(&value, ctx) {
                            return false;
                        }
                    }
                }
                if !has_match && !self.node.is_valid(&value, ctx) {
                    return false;
                }
            }
        }
        true
    }

    fn validate<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> Result<(), ValidationError<'i>> {
        if let Some(object) = instance.as_object() {
            for (property, value) in object.members() {
                let property_location = location.push(property.as_ref());
                let mut has_match = false;
                for (re, node) in &self.patterns {
                    if re.is_match(property.as_ref()).unwrap_or(false) {
                        has_match = true;
                        node.validate(&value, &property_location, tracker, ctx)?;
                    }
                }
                if !has_match {
                    self.node
                        .validate(&value, &property_location, tracker, ctx)?;
                }
            }
        }
        Ok(())
    }

    fn collect_errors<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
        errors: &mut Vec<ValidationError<'i>>,
    ) {
        let Some(object) = instance.as_object() else {
            return;
        };
        for (property, value) in object.members() {
            let mut has_match = false;
            for (re, node) in &self.patterns {
                if re.is_match(property.as_ref()).unwrap_or(false) {
                    has_match = true;
                    node.collect_errors(
                        &value,
                        &location.push(property.as_ref()),
                        tracker,
                        ctx,
                        errors,
                    );
                }
            }
            if !has_match {
                self.node.collect_errors(
                    &value,
                    &location.push(property.as_ref()),
                    tracker,
                    ctx,
                    errors,
                );
            }
        }
    }

    fn evaluate(
        &self,
        instance: &F::Node<'_>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> EvaluationResult {
        if let Some(object) = instance.as_object() {
            let mut pattern_matched_propnames = Vec::with_capacity(object.len());
            let mut additional_matched_propnames = Vec::with_capacity(object.len());
            let mut children = ChildList::default();
            for (property, value) in object.members() {
                let path = location.push(property.as_ref());
                let mut has_match = false;
                for (pattern, node) in &self.patterns {
                    if pattern.is_match(property.as_ref()).unwrap_or(false) {
                        has_match = true;
                        pattern_matched_propnames.push(property.as_ref().to_owned());
                        let child = node.evaluate_instance_below(&value, &path, tracker, ctx);
                        children.push(&mut ctx.arena, child);
                    }
                }
                if !has_match {
                    additional_matched_propnames.push(property.as_ref().to_owned());
                    let child = self
                        .node
                        .evaluate_instance_below(&value, &path, tracker, ctx);
                    children.push(&mut ctx.arena, child);
                }
            }
            if !pattern_matched_propnames.is_empty() {
                let annotation = Annotations::new(Value::from(pattern_matched_propnames));
                let schema_location = crate::validation::evaluation::format_keyword_location(
                    &self.pattern_keyword_path,
                    self.pattern_keyword_absolute_location.as_ref(),
                );
                let child = EvaluationNode::valid(
                    self.pattern_keyword_path.clone(),
                    self.pattern_keyword_absolute_location.clone(),
                    schema_location,
                    location.into(),
                    Some(annotation),
                    ChildList::default(),
                );
                children.push(&mut ctx.arena, child);
            }
            let mut result = EvaluationResult::from_children(children);
            if !additional_matched_propnames.is_empty() {
                result.annotate(Annotations::new(Value::from(additional_matched_propnames)));
            }
            result
        } else {
            EvaluationResult::valid_empty()
        }
    }
}

/// # Schema example
///
/// ```json
/// {
///     "additionalProperties": false,
///     "patternProperties": {
///         "^x-": {"type": "integer", "minimum": 5},
///         "-x$": {"type": "integer", "maximum": 10}
///     }
/// }
/// ```
///
/// # Valid value
///
/// ```json
/// {
///     "x-bar": 6,
///     "spam-x": 7,
///     "x-baz-x": 8,
/// }
/// ```
pub(crate) struct AdditionalPropertiesWithPatternsFalseValidator<R, F: Json = JsonValueBackend> {
    patterns: Vec<(R, SchemaNode<F>)>,
    location: Location,
    pattern_keyword_path: Location,
    pattern_keyword_absolute_location: Option<Arc<Uri<String>>>,
}

impl<F: Json, R: RegexEngine> Validate<F> for AdditionalPropertiesWithPatternsFalseValidator<R, F> {
    fn is_valid(&self, instance: &F::Node<'_>, ctx: &mut ValidationContext) -> bool {
        if let Some(object) = instance.as_object() {
            for (property, value) in object.members() {
                let mut has_match = false;
                for (re, node) in &self.patterns {
                    if re.is_match(property.as_ref()).unwrap_or(false) {
                        has_match = true;
                        if !node.is_valid(&value, ctx) {
                            return false;
                        }
                    }
                }
                if !has_match {
                    return false;
                }
            }
        }
        true
    }

    fn validate<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> Result<(), ValidationError<'i>> {
        if let Some(object) = instance.as_object() {
            for (property, value) in object.members() {
                let property_location = location.push(property.as_ref());
                let mut has_match = false;
                for (re, node) in &self.patterns {
                    if re.is_match(property.as_ref()).unwrap_or(false) {
                        has_match = true;
                        node.validate(&value, &property_location, tracker, ctx)?;
                    }
                }
                if !has_match {
                    return Err(ValidationError::additional_properties(
                        self.location.clone(),
                        crate::validation::paths::capture_evaluation_path(tracker, &self.location),
                        location.into(),
                        instance.lazy_value(),
                        vec![property.as_ref().to_owned()],
                    ));
                }
            }
        }
        Ok(())
    }

    fn collect_errors<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
        errors: &mut Vec<ValidationError<'i>>,
    ) {
        let Some(object) = instance.as_object() else {
            return;
        };
        let mut unexpected = vec![];
        for (property, value) in object.members() {
            let mut has_match = false;
            for (re, node) in &self.patterns {
                if re.is_match(property.as_ref()).unwrap_or(false) {
                    has_match = true;
                    node.collect_errors(
                        &value,
                        &location.push(property.as_ref()),
                        tracker,
                        ctx,
                        errors,
                    );
                }
            }
            if !has_match {
                unexpected.push(property.as_ref().to_owned());
            }
        }
        if !unexpected.is_empty() {
            errors.push(ValidationError::additional_properties(
                self.location.clone(),
                crate::validation::paths::capture_evaluation_path(tracker, &self.location),
                location.into(),
                instance.lazy_value(),
                unexpected,
            ));
        }
    }

    fn evaluate(
        &self,
        instance: &F::Node<'_>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> EvaluationResult {
        if let Some(object) = instance.as_object() {
            let mut unexpected = Vec::with_capacity(object.len());
            let mut pattern_matched_props = Vec::with_capacity(object.len());
            let mut children = ChildList::default();
            for (property, value) in object.members() {
                let path = location.push(property.as_ref());
                let mut has_match = false;
                for (pattern, node) in &self.patterns {
                    if pattern.is_match(property.as_ref()).unwrap_or(false) {
                        has_match = true;
                        pattern_matched_props.push(property.as_ref().to_owned());
                        let child = node.evaluate_instance_below(&value, &path, tracker, ctx);
                        children.push(&mut ctx.arena, child);
                    }
                }
                if !has_match {
                    unexpected.push(property.as_ref().to_owned());
                }
            }
            if !pattern_matched_props.is_empty() {
                let annotation = Annotations::new(Value::from(pattern_matched_props));
                let schema_location = crate::validation::evaluation::format_keyword_location(
                    &self.pattern_keyword_path,
                    self.pattern_keyword_absolute_location.as_ref(),
                );
                let child = EvaluationNode::valid(
                    self.pattern_keyword_path.clone(),
                    self.pattern_keyword_absolute_location.clone(),
                    schema_location,
                    location.into(),
                    Some(annotation),
                    ChildList::default(),
                );
                children.push(&mut ctx.arena, child);
            }
            let mut result = EvaluationResult::from_children(children);
            if !unexpected.is_empty() {
                let eval_path =
                    crate::validation::paths::capture_evaluation_path(tracker, &self.location);
                result.mark_errored(ErrorDescription::from_validation_error(
                    &ValidationError::additional_properties(
                        self.location.clone(),
                        eval_path,
                        location.into(),
                        instance.lazy_value(),
                        unexpected,
                    ),
                ));
            }
            result
        } else {
            EvaluationResult::valid_empty()
        }
    }
}

/// # Schema example
///
/// ```json
/// {
///     "additionalProperties": {"type": "integer"},
///     "properties": {
///         "foo": {"type": "string"}
///     },
///     "patternProperties": {
///         "^x-": {"type": "integer", "minimum": 5},
///         "-x$": {"type": "integer", "maximum": 10}
///     }
/// }
/// ```
///
/// # Valid value
///
/// ```json
/// {
///     "foo": "a",
///     "x-spam": 6,
///     "spam-x": 7,
///     "x-spam-x": 8,
///     "bar": 42
/// }
/// ```
pub(crate) struct AdditionalPropertiesWithPatternsNotEmptyValidator<
    M,
    R,
    F: Json = JsonValueBackend,
> {
    node: SchemaNode<F>,
    properties: M,
    patterns: Vec<(R, SchemaNode<F>)>,
    /// Pre-computed pattern indices for properties defined in `properties`.
    /// Maps property name -> indices into `patterns` Vec for patterns that match.
    /// Eliminates regex matching at validation time for known properties.
    property_pattern_indices: AHashMap<String, Box<[usize]>>,
}

impl<F: Json, M: PropertiesValidatorsMap<F>, R: RegexEngine> Validate<F>
    for AdditionalPropertiesWithPatternsNotEmptyValidator<M, R, F>
{
    fn is_valid(&self, instance: &F::Node<'_>, ctx: &mut ValidationContext) -> bool {
        if let Some(object) = instance.as_object() {
            for (property, value) in object.members() {
                if let Some(node) = self.properties.get_validator(property.as_ref()) {
                    if !node.is_valid(&value, ctx) {
                        return false;
                    }
                    // Use pre-computed pattern indices - no regex at runtime
                    if let Some(pattern_indices) =
                        self.property_pattern_indices.get(property.as_ref())
                    {
                        for &idx in pattern_indices {
                            if !self.patterns[idx].1.is_valid(&value, ctx) {
                                return false;
                            }
                        }
                    }
                } else {
                    // Unknown property - need runtime regex matching
                    let mut has_match = false;
                    for (re, node) in &self.patterns {
                        if re.is_match(property.as_ref()).unwrap_or(false) {
                            has_match = true;
                            if !node.is_valid(&value, ctx) {
                                return false;
                            }
                        }
                    }
                    if !has_match && !self.node.is_valid(&value, ctx) {
                        return false;
                    }
                }
            }
            true
        } else {
            true
        }
    }

    fn validate<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> Result<(), ValidationError<'i>> {
        if let Some(object) = instance.as_object() {
            for (property, value) in object.members() {
                if let Some((name, node)) = self.properties.get_key_validator(property.as_ref()) {
                    let name_location = location.push(name);
                    node.validate(&value, &name_location, tracker, ctx)?;
                    // Use pre-computed pattern indices - no regex at runtime
                    if let Some(pattern_indices) =
                        self.property_pattern_indices.get(property.as_ref())
                    {
                        for &idx in pattern_indices {
                            self.patterns[idx]
                                .1
                                .validate(&value, &name_location, tracker, ctx)?;
                        }
                    }
                } else {
                    // Unknown property - need runtime regex matching
                    let property_location = location.push(property.as_ref());
                    let mut has_match = false;
                    for (re, node) in &self.patterns {
                        if re.is_match(property.as_ref()).unwrap_or(false) {
                            has_match = true;
                            node.validate(&value, &property_location, tracker, ctx)?;
                        }
                    }
                    if !has_match {
                        self.node
                            .validate(&value, &property_location, tracker, ctx)?;
                    }
                }
            }
        }
        Ok(())
    }

    fn collect_errors<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
        errors: &mut Vec<ValidationError<'i>>,
    ) {
        let Some(object) = instance.as_object() else {
            return;
        };
        for (property, value) in object.members() {
            if let Some((name, node)) = self.properties.get_key_validator(property.as_ref()) {
                let name_location = location.push(name);
                node.collect_errors(&value, &name_location, tracker, ctx, errors);
                // Use pre-computed pattern indices - no regex at runtime
                if let Some(pattern_indices) = self.property_pattern_indices.get(property.as_ref())
                {
                    for &idx in pattern_indices {
                        self.patterns[idx].1.collect_errors(
                            &value,
                            &name_location,
                            tracker,
                            ctx,
                            errors,
                        );
                    }
                }
            } else {
                // Unknown property - need runtime regex matching
                let mut has_match = false;
                for (re, node) in &self.patterns {
                    if re.is_match(property.as_ref()).unwrap_or(false) {
                        has_match = true;
                        node.collect_errors(
                            &value,
                            &location.push(property.as_ref()),
                            tracker,
                            ctx,
                            errors,
                        );
                    }
                }
                if !has_match {
                    self.node.collect_errors(
                        &value,
                        &location.push(property.as_ref()),
                        tracker,
                        ctx,
                        errors,
                    );
                }
            }
        }
    }

    fn evaluate(
        &self,
        instance: &F::Node<'_>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> EvaluationResult {
        if let Some(object) = instance.as_object() {
            let mut additional_matches = Vec::with_capacity(object.len());
            let mut children = ChildList::default();
            for (property, value) in object.members() {
                let path = location.push(property.as_ref());
                if let Some((_name, node)) = self.properties.get_key_validator(property.as_ref()) {
                    let child = node.evaluate_instance_below(&value, &path, tracker, ctx);
                    children.push(&mut ctx.arena, child);
                    // Use pre-computed pattern indices - no regex at runtime
                    if let Some(pattern_indices) =
                        self.property_pattern_indices.get(property.as_ref())
                    {
                        for &idx in pattern_indices {
                            let child = self.patterns[idx]
                                .1
                                .evaluate_instance_below(&value, &path, tracker, ctx);
                            children.push(&mut ctx.arena, child);
                        }
                    }
                } else {
                    // Unknown property - need runtime regex matching
                    let mut has_match = false;
                    for (pattern, node) in &self.patterns {
                        if pattern.is_match(property.as_ref()).unwrap_or(false) {
                            has_match = true;
                            let child = node.evaluate_instance_below(&value, &path, tracker, ctx);
                            children.push(&mut ctx.arena, child);
                        }
                    }
                    if !has_match {
                        additional_matches.push(property.as_ref().to_owned());
                        let child = self
                            .node
                            .evaluate_instance_below(&value, &path, tracker, ctx);
                        children.push(&mut ctx.arena, child);
                    }
                }
            }
            let mut result = EvaluationResult::from_children(children);
            result.annotate(Annotations::new(Value::from(additional_matches)));
            result
        } else {
            EvaluationResult::valid_empty()
        }
    }
}

/// # Schema example
///
/// ```json
/// {
///     "additionalProperties": false,
///     "properties": {
///         "foo": {"type": "string"}
///     },
///     "patternProperties": {
///         "^x-": {"type": "integer", "minimum": 5},
///         "-x$": {"type": "integer", "maximum": 10}
///     }
/// }
/// ```
///
/// # Valid value
///
/// ```json
/// {
///     "foo": "bar",
///     "x-bar": 6,
///     "spam-x": 7,
///     "x-baz-x": 8,
/// }
/// ```
pub(crate) struct AdditionalPropertiesWithPatternsNotEmptyFalseValidator<
    M,
    R,
    F: Json = JsonValueBackend,
> {
    properties: M,
    patterns: Vec<(R, SchemaNode<F>)>,
    /// Pre-computed pattern indices for properties defined in `properties`.
    /// Maps property name -> indices into `patterns` Vec for patterns that match.
    /// Eliminates regex matching at validation time for known properties.
    property_pattern_indices: AHashMap<String, Box<[usize]>>,
    location: Location,
}

impl<F: Json, M: PropertiesValidatorsMap<F>, R: RegexEngine> Validate<F>
    for AdditionalPropertiesWithPatternsNotEmptyFalseValidator<M, R, F>
{
    fn is_valid(&self, instance: &F::Node<'_>, ctx: &mut ValidationContext) -> bool {
        if let Some(object) = instance.as_object() {
            for (property, value) in object.members() {
                if let Some(node) = self.properties.get_validator(property.as_ref()) {
                    if !node.is_valid(&value, ctx) {
                        return false;
                    }
                    // Use pre-computed pattern indices - no regex at runtime for known properties
                    if let Some(pattern_indices) =
                        self.property_pattern_indices.get(property.as_ref())
                    {
                        for &idx in pattern_indices {
                            if !self.patterns[idx].1.is_valid(&value, ctx) {
                                return false;
                            }
                        }
                    }
                } else {
                    // Unknown property - need runtime regex matching
                    let mut has_match = false;
                    for (re, node) in &self.patterns {
                        if re.is_match(property.as_ref()).unwrap_or(false) {
                            has_match = true;
                            if !node.is_valid(&value, ctx) {
                                return false;
                            }
                        }
                    }
                    if !has_match {
                        return false;
                    }
                }
            }
        }
        true
    }

    fn validate<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> Result<(), ValidationError<'i>> {
        if let Some(object) = instance.as_object() {
            for (property, value) in object.members() {
                if let Some((name, node)) = self.properties.get_key_validator(property.as_ref()) {
                    let name_location = location.push(name);
                    node.validate(&value, &name_location, tracker, ctx)?;
                    // Use pre-computed pattern indices - no regex at runtime
                    if let Some(pattern_indices) =
                        self.property_pattern_indices.get(property.as_ref())
                    {
                        for &idx in pattern_indices {
                            self.patterns[idx]
                                .1
                                .validate(&value, &name_location, tracker, ctx)?;
                        }
                    }
                } else {
                    // Unknown property - need runtime regex matching
                    let property_location = location.push(property.as_ref());
                    let mut has_match = false;
                    for (re, node) in &self.patterns {
                        if re.is_match(property.as_ref()).unwrap_or(false) {
                            has_match = true;
                            node.validate(&value, &property_location, tracker, ctx)?;
                        }
                    }
                    if !has_match {
                        return Err(ValidationError::additional_properties(
                            self.location.clone(),
                            crate::validation::paths::capture_evaluation_path(
                                tracker,
                                &self.location,
                            ),
                            location.into(),
                            instance.lazy_value(),
                            vec![property.as_ref().to_owned()],
                        ));
                    }
                }
            }
        }
        Ok(())
    }

    fn collect_errors<'i>(
        &self,
        instance: &F::Node<'i>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
        errors: &mut Vec<ValidationError<'i>>,
    ) {
        let Some(object) = instance.as_object() else {
            return;
        };
        let mut unexpected = vec![];
        for (property, value) in object.members() {
            if let Some((name, node)) = self.properties.get_key_validator(property.as_ref()) {
                let name_location = location.push(name);
                node.collect_errors(&value, &name_location, tracker, ctx, errors);
                // Use pre-computed pattern indices - no regex at runtime
                if let Some(pattern_indices) = self.property_pattern_indices.get(property.as_ref())
                {
                    for &idx in pattern_indices {
                        self.patterns[idx].1.collect_errors(
                            &value,
                            &name_location,
                            tracker,
                            ctx,
                            errors,
                        );
                    }
                }
            } else {
                // Unknown property - need runtime regex matching
                let mut has_match = false;
                for (re, node) in &self.patterns {
                    if re.is_match(property.as_ref()).unwrap_or(false) {
                        has_match = true;
                        node.collect_errors(
                            &value,
                            &location.push(property.as_ref()),
                            tracker,
                            ctx,
                            errors,
                        );
                    }
                }
                if !has_match {
                    unexpected.push(property.as_ref().to_owned());
                }
            }
        }
        if !unexpected.is_empty() {
            errors.push(ValidationError::additional_properties(
                self.location.clone(),
                crate::validation::paths::capture_evaluation_path(tracker, &self.location),
                location.into(),
                instance.lazy_value(),
                unexpected,
            ));
        }
    }

    fn evaluate(
        &self,
        instance: &F::Node<'_>,
        location: &LazyLocation,
        tracker: Option<&RefTracker>,
        ctx: &mut ValidationContext,
    ) -> EvaluationResult {
        if let Some(object) = instance.as_object() {
            let mut unexpected = vec![];
            let mut children = ChildList::default();
            for (property, value) in object.members() {
                let path = location.push(property.as_ref());
                if let Some((_name, node)) = self.properties.get_key_validator(property.as_ref()) {
                    let child = node.evaluate_instance_below(&value, &path, tracker, ctx);
                    children.push(&mut ctx.arena, child);
                    // Use pre-computed pattern indices - no regex at runtime
                    if let Some(pattern_indices) =
                        self.property_pattern_indices.get(property.as_ref())
                    {
                        for &idx in pattern_indices {
                            let child = self.patterns[idx]
                                .1
                                .evaluate_instance_below(&value, &path, tracker, ctx);
                            children.push(&mut ctx.arena, child);
                        }
                    }
                } else {
                    // Unknown property - need runtime regex matching
                    let mut has_match = false;
                    for (pattern, node) in &self.patterns {
                        if pattern.is_match(property.as_ref()).unwrap_or(false) {
                            has_match = true;
                            let child = node.evaluate_instance_below(&value, &path, tracker, ctx);
                            children.push(&mut ctx.arena, child);
                        }
                    }
                    if !has_match {
                        unexpected.push(property.as_ref().to_owned());
                    }
                }
            }
            let mut result = EvaluationResult::from_children(children);
            if !unexpected.is_empty() {
                let eval_path =
                    crate::validation::paths::capture_evaluation_path(tracker, &self.location);
                result.mark_errored(ErrorDescription::from_validation_error(
                    &ValidationError::additional_properties(
                        self.location.clone(),
                        eval_path,
                        location.into(),
                        instance.lazy_value(),
                        unexpected,
                    ),
                ));
            }
            result
        } else {
            EvaluationResult::valid_empty()
        }
    }
}

macro_rules! try_compile {
    ($expr:expr) => {
        match $expr {
            Ok(result) => result,
            Err(error) => return Some(Err(error)),
        }
    };
}

/// Pre-compute which `patternProperties` patterns match each property name from `properties`.
/// This eliminates regex matching at validation time for known properties.
fn precompute_property_pattern_indices<R: RegexEngine, F: Json>(
    property_names: impl Iterator<Item = impl AsRef<str> + Clone + Into<String>>,
    patterns: &[(R, SchemaNode<F>)],
) -> AHashMap<String, Box<[usize]>> {
    let mut result = AHashMap::new();
    for prop_name in property_names {
        let matching_indices: Vec<usize> = patterns
            .iter()
            .enumerate()
            .filter(|(_, (re, _))| re.is_match(prop_name.as_ref()).unwrap_or(false))
            .map(|(i, _)| i)
            .collect();
        if !matching_indices.is_empty() {
            result.insert(prop_name.into(), matching_indices.into_boxed_slice());
        }
    }
    result
}

fn compile_pattern_non_empty<'a, R, F: Json>(
    ctx: &compiler::Context<F>,
    map: &'a Map<String, Value>,
    patterns: Vec<(R, SchemaNode<F>)>,
    schema: &'a Value,
) -> Option<CompilationResult<'a, F>>
where
    R: RegexEngine + 'static,
{
    let kctx = ctx.new_at_location("additionalProperties");
    let property_pattern_indices = precompute_property_pattern_indices(map.keys(), &patterns);

    if map.len() < HASHMAP_THRESHOLD {
        Some(Ok(Box::new(
            AdditionalPropertiesWithPatternsNotEmptyValidator::<SmallValidatorsMap<F>, R, F> {
                node: try_compile!(compiler::compile(&kctx, kctx.as_resource_ref(schema))),
                properties: try_compile!(compile_small_map(ctx, map)),
                patterns,
                property_pattern_indices,
            },
        )))
    } else {
        Some(Ok(Box::new(
            AdditionalPropertiesWithPatternsNotEmptyValidator::<BigValidatorsMap<F>, R, F> {
                node: try_compile!(compiler::compile(&kctx, kctx.as_resource_ref(schema))),
                properties: try_compile!(compile_big_map(ctx, map)),
                patterns,
                property_pattern_indices,
            },
        )))
    }
}

fn compile_pattern_non_empty_false<'a, R, F: Json>(
    ctx: &compiler::Context<F>,
    map: &'a Map<String, Value>,
    patterns: Vec<(R, SchemaNode<F>)>,
) -> Option<CompilationResult<'a, F>>
where
    R: RegexEngine + 'static,
{
    let kctx = ctx.new_at_location("additionalProperties");
    let property_pattern_indices = precompute_property_pattern_indices(map.keys(), &patterns);

    if map.len() < HASHMAP_THRESHOLD {
        Some(Ok(Box::new(
            AdditionalPropertiesWithPatternsNotEmptyFalseValidator::<SmallValidatorsMap<F>, R, F> {
                properties: try_compile!(compile_small_map(ctx, map)),
                patterns,
                property_pattern_indices,
                location: kctx.location().clone(),
            },
        )))
    } else {
        Some(Ok(Box::new(
            AdditionalPropertiesWithPatternsNotEmptyFalseValidator::<BigValidatorsMap<F>, R, F> {
                properties: try_compile!(compile_big_map(ctx, map)),
                patterns,
                property_pattern_indices,
                location: kctx.location().clone(),
            },
        )))
    }
}

#[inline]
pub(crate) fn compile<'a, F: Json>(
    ctx: &compiler::Context<F>,
    parent: &'a Map<String, Value>,
    schema: &'a Value,
) -> Option<CompilationResult<'a, F>> {
    let properties = parent.get("properties");
    if let Some(patterns) = parent.get("patternProperties") {
        if let Value::Object(obj) = patterns {
            // Compile all patterns & their validators to avoid doing work in the `patternProperties` validator
            match ctx.config().pattern_options() {
                PatternEngineOptions::FancyRegex { .. } => {
                    let patterns = match compile_fancy_regex_patterns(ctx, obj) {
                        Ok(patterns) => patterns,
                        Err(error) => return Some(Err(error)),
                    };
                    match schema {
                        Value::Bool(true) => None, // "additionalProperties" are "true" by default
                        Value::Bool(false) => {
                            if let Some(properties) = properties {
                                if let Value::Object(map) = properties {
                                    compile_pattern_non_empty_false::<
                                        CompiledPattern<fancy_regex::Regex>,
                                        F,
                                    >(ctx, map, patterns)
                                } else {
                                    let location = ctx.location().join("properties");
                                    Some(Err(ValidationError::compile_error(
                                        location.clone(),
                                        location,
                                        Location::new(),
                                        LazyInstance::Ready(Cow::Borrowed(properties)),
                                        "Unexpected type",
                                    )))
                                }
                            } else {
                                Some(Ok(Box::new(
                                    AdditionalPropertiesWithPatternsFalseValidator {
                                        patterns,
                                        location: ctx.location().join("additionalProperties"),
                                        pattern_keyword_path: ctx
                                            .location()
                                            .join("patternProperties"),
                                        pattern_keyword_absolute_location: ctx.absolute_location(
                                            &ctx.location().join("patternProperties"),
                                        ),
                                    },
                                )))
                            }
                        }
                        _ => {
                            if let Some(properties) = properties {
                                if let Value::Object(map) = properties {
                                    compile_pattern_non_empty::<
                                        CompiledPattern<fancy_regex::Regex>,
                                        F,
                                    >(ctx, map, patterns, schema)
                                } else {
                                    let location = ctx.location().join("properties");
                                    Some(Err(ValidationError::compile_error(
                                        location.clone(),
                                        location,
                                        Location::new(),
                                        LazyInstance::Ready(Cow::Borrowed(properties)),
                                        "Unexpected type",
                                    )))
                                }
                            } else {
                                let kctx = ctx.new_at_location("additionalProperties");
                                Some(Ok(Box::new(AdditionalPropertiesWithPatternsValidator {
                                    node: try_compile!(compiler::compile(
                                        &kctx,
                                        kctx.as_resource_ref(schema),
                                    )),
                                    patterns,
                                    pattern_keyword_path: ctx.location().join("patternProperties"),
                                    pattern_keyword_absolute_location: ctx.absolute_location(
                                        &ctx.location().join("patternProperties"),
                                    ),
                                })))
                            }
                        }
                    }
                }
                PatternEngineOptions::Regex { .. } => {
                    let patterns = match compile_regex_patterns(ctx, obj) {
                        Ok(patterns) => patterns,
                        Err(error) => return Some(Err(error)),
                    };
                    match schema {
                        Value::Bool(true) => None, // "additionalProperties" are "true" by default
                        Value::Bool(false) => {
                            if let Some(properties) = properties {
                                if let Value::Object(map) = properties {
                                    compile_pattern_non_empty_false::<
                                        CompiledPattern<regex::Regex>,
                                        F,
                                    >(ctx, map, patterns)
                                } else {
                                    let location = ctx.location().join("properties");
                                    Some(Err(ValidationError::compile_error(
                                        location.clone(),
                                        location,
                                        Location::new(),
                                        LazyInstance::Ready(Cow::Borrowed(properties)),
                                        "Unexpected type",
                                    )))
                                }
                            } else {
                                Some(Ok(Box::new(
                                    AdditionalPropertiesWithPatternsFalseValidator {
                                        patterns,
                                        location: ctx.location().join("additionalProperties"),
                                        pattern_keyword_path: ctx
                                            .location()
                                            .join("patternProperties"),
                                        pattern_keyword_absolute_location: ctx.absolute_location(
                                            &ctx.location().join("patternProperties"),
                                        ),
                                    },
                                )))
                            }
                        }
                        _ => {
                            if let Some(properties) = properties {
                                if let Value::Object(map) = properties {
                                    compile_pattern_non_empty::<CompiledPattern<regex::Regex>, F>(
                                        ctx, map, patterns, schema,
                                    )
                                } else {
                                    let location = ctx.location().join("properties");
                                    Some(Err(ValidationError::compile_error(
                                        location.clone(),
                                        location,
                                        Location::new(),
                                        LazyInstance::Ready(Cow::Borrowed(properties)),
                                        "Unexpected type",
                                    )))
                                }
                            } else {
                                let kctx = ctx.new_at_location("additionalProperties");
                                Some(Ok(Box::new(AdditionalPropertiesWithPatternsValidator {
                                    node: try_compile!(compiler::compile(
                                        &kctx,
                                        kctx.as_resource_ref(schema),
                                    )),
                                    patterns,
                                    pattern_keyword_path: ctx.location().join("patternProperties"),
                                    pattern_keyword_absolute_location: ctx.absolute_location(
                                        &ctx.location().join("patternProperties"),
                                    ),
                                })))
                            }
                        }
                    }
                }
            }
        } else {
            let location = ctx.location().join("patternProperties");
            Some(Err(ValidationError::single_type_error(
                location.clone(),
                location,
                Location::new(),
                LazyInstance::Ready(Cow::Borrowed(patterns)),
                JsonType::Object,
            )))
        }
    } else {
        match schema {
            Value::Bool(true) => None, // "additionalProperties" are "true" by default
            Value::Bool(false) => {
                if let Some(properties) = properties {
                    // Fuse `required`, which compiles under the validation vocabulary only
                    if let Some(Value::Array(required)) = parent.get("required").filter(|_| {
                        ctx.has_vocabulary(&Vocabulary::Validation)
                            && !ctx.is_keyword_overridden("required")
                    }) {
                        if required.len() == 1 {
                            if let Some(Value::String(req)) = required.first() {
                                if let Value::Object(map) = properties {
                                    return if map.len() < HASHMAP_THRESHOLD {
                                        Some(
                                            AdditionalPropertiesNotEmptyFalseWithRequired1Validator::<
                                                SmallValidatorsMap<F>,
                                            >::compile(
                                                map, ctx, req.clone()
                                            ),
                                        )
                                    } else {
                                        Some(
                                            AdditionalPropertiesNotEmptyFalseWithRequired1Validator::<
                                                BigValidatorsMap<F>,
                                            >::compile(
                                                map, ctx, req.clone()
                                            ),
                                        )
                                    };
                                }
                            }
                        }
                    }
                    compile_dynamic_prop_map_validator!(
                        AdditionalPropertiesNotEmptyFalseValidator,
                        properties,
                        ctx,
                    )
                } else {
                    let location = ctx.location().join("additionalProperties");
                    Some(AdditionalPropertiesFalseValidator::compile(location))
                }
            }
            _ => {
                if let Some(properties) = properties {
                    compile_dynamic_prop_map_validator!(
                        AdditionalPropertiesNotEmptyValidator,
                        properties,
                        ctx,
                        schema,
                    )
                } else {
                    Some(AdditionalPropertiesValidator::compile(schema, ctx))
                }
            }
        }
    }
}

#[cfg(test)]
include!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../../test/foundation/schema-validation/upstream/jsonschema/unit/src/keywords/additional_properties/tests_1891.rs"
));
